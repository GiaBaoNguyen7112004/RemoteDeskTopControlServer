package com.baotruongtuan.RdpServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RdpServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
