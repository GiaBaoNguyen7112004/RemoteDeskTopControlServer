package com.baotruongtuan.RdpServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RdpServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(RdpServerApplication.class, args);
	}

}
